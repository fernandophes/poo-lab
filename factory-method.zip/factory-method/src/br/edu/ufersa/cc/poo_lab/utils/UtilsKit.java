package br.edu.ufersa.cc.poo_lab.utils;

import br.edu.ufersa.cc.poo_lab.logger.Logger;

public interface UtilsKit {

    String getClassName(Class<?> clazz);

    // Vos apresento o Factory Method
    Logger createLogger(String name);

    default Logger createLogger(final Class<?> clazz) {
        return createLogger(getClassName(clazz));
    }

}
