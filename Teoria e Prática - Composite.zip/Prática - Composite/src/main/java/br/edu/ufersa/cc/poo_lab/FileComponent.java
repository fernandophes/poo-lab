package br.edu.ufersa.cc.poo_lab;

public interface FileComponent {

    String getName();

    long getSizeInBytes();

    void printStructure(String prefix);

}
