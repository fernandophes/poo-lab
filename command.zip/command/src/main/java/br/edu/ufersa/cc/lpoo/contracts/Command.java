package br.edu.ufersa.cc.lpoo.contracts;

@FunctionalInterface
public interface Command {

    void execute();

}
