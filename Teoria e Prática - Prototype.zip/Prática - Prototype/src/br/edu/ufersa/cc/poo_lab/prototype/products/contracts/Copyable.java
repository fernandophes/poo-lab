package br.edu.ufersa.cc.poo_lab.prototype.products.contracts;

public interface Copyable<T> {

    T copy();

}
