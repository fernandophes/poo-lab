package br.edu.ufersa.cc.poo_lab.singleton.connection;

public interface DatabaseConnection {

    String query();

}
